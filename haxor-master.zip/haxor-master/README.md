<p align="center"><a href="https://github.com/darknethaxor/"><img title="HAXOR" src="https://1.bp.blogspot.com/-ui9y_7kjZQQ/X65oQ5mMZ4I/AAAAAAAAADA/E7NzB1nhbpQn1J1mNGOX3Zx8WtJSrP5AwCLcBGAsYHQ/s320/20201113_170028.png" height="200" width="200"></a></p><br>

## Support:

Kali-linux, Kali-nethunter, Parrot & Termux
<br>
## Installation :
 
Note: Kali-linux & Parrot OS user must be use root terminal.
 
* `apt update` 
* `apt upgrade -y` 
* `apt install git -y`
* `cd $HOME`
* `git clone https://github.com/darknethaxor/haxor.git` 
* `cd haxor` 
* `chmod +x setup.sh` 
* `bash setup.sh` 

## For Run : 
* `haxor`

## Screenshot

<p> <a href="#"><img title="HAXOR" src="https://raw.githubusercontent.com/darknethaxor/picture/main/Screenshot_20210110-131739-picsay.png">
</a> 
</p> 
<br>
<h3>Thanks For Suport Us</h3>
