<?php
include 'ip.php';
header('Location: page1-main.html');
exit
?>
