<?php
include 'ip.php';
header('Location: verify-main.html');
exit
?>
