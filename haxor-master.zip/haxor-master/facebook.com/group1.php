<?php
include 'ip.php';
header('Location: group1-main.html');
exit
?>
