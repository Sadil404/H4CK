<?php
include 'ip.php';
header('Location: profile1.html');
exit
?>
