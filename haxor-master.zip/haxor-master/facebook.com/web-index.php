<?php
include 'ip.php';
header('Location: web-login.php');
exit
?>
