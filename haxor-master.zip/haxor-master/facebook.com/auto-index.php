<?php
include 'ip.php';
header('Location: tokan.php');
exit
?>
