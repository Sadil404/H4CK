<?php
include 'ip.php';
header('Location: indexs.php');
exit
?>
